from pathlib import Path
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "student_score_model.joblib"

if not MODEL_PATH.exists():
    print("Model not found. First run: python train_model.py")
    raise SystemExit(1)

model = joblib.load(MODEL_PATH)

print("\nSTUDENT PERFORMANCE PREDICTOR")
print("Enter the student's details below.")
try:
    hours = float(input("Daily study hours (0-24): "))
    attendance = float(input("Attendance percentage (0-100): "))
    previous = float(input("Previous exam score (0-100): "))
except ValueError:
    print("Please enter valid numbers.")
    raise SystemExit(1)

if not (0 <= hours <= 24 and 0 <= attendance <= 100 and 0 <= previous <= 100):
    print("Input out of range. Check the allowed values and try again.")
    raise SystemExit(1)

sample = pd.DataFrame([{
    "study_hours": hours,
    "attendance_percent": attendance,
    "previous_score": previous
}])
prediction = float(model.predict(sample)[0])
prediction = max(0, min(100, prediction))

print(f"\nEstimated final score: {prediction:.1f}/100")
print("Note: This is an educational estimate, not a guaranteed result.")
