# Student Performance Predictor (Machine Learning)

A beginner-friendly machine-learning project that estimates a student's final exam score from:
- Daily study hours
- Attendance percentage
- Previous exam score

It uses **Python, Pandas, scikit-learn, Matplotlib and Random Forest Regression**.

## Project structure

```text
student_performance_ai/
├── app.py
├── train_model.py
├── requirements.txt
├── data/
│   └── student_data.csv
├── models/                 # trained model is saved here
├── outputs/                # charts are saved here
└── README.md
```

## 1. Requirements

- Python 3.10 or newer
- Internet connection for installing packages
- VS Code or another Python editor (optional)

## 2. Install and run

Open a terminal in this project folder.

### Windows

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python train_model.py
python app.py
```

If `python` is not recognized, try using `py` instead.

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python train_model.py
python app.py
```

Run `train_model.py` first. It trains the model, prints evaluation metrics, saves the trained model in `models/`, and creates charts in `outputs/`. Then run `app.py` to enter a student's details and get a prediction.

## 3. Sample input

```text
Daily study hours (0-24): 4
Attendance percentage (0-100): 85
Previous exam score (0-100): 70
```

The predicted score will vary slightly with package versions and the training data.

## 4. How it works

1. Pandas loads the CSV dataset.
2. The data is split into training and testing sets.
3. A Random Forest Regressor learns patterns from the training data.
4. MAE, RMSE and R-squared evaluate test-set performance.
5. Matplotlib saves an actual-vs-predicted chart and a feature-importance chart.
6. The command-line app loads the saved model and predicts a score for new input.

## 5. Dataset

`data/student_data.csv` contains 150 **synthetic sample records** created for this learning project. It is not real student data and should not be used to make important academic decisions. Replace it with an authorized, reliable dataset before drawing real-world conclusions.

## 6. Publish on GitHub

1. Create or sign in to your account at https://github.com.
2. Select **New repository** and name it `student-performance-predictor`.
3. Keep it public if your assignment requires a public repository.
4. In your project terminal, run:

```bash
git init
git add .
git commit -m "Add student performance prediction ML project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/student-performance-predictor.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. If Git asks you to authenticate, follow GitHub's sign-in prompt.

## 7. Before submission

- [ ] Run `python train_model.py` without errors.
- [ ] Run `python app.py` and test at least two inputs.
- [ ] Check that both chart images are created in `outputs/`.
- [ ] Update this README with your name, course and what you learned if required.
- [ ] Push the complete project to GitHub.
- [ ] Copy the GitHub repository URL and submit it through your assignment portal.

## Learning outcomes

- Loading and exploring CSV data with Pandas
- Separating features and target values
- Training and testing a regression model
- Evaluating predictions with MAE, RMSE and R-squared
- Creating Matplotlib visualizations
- Saving and reusing a trained model
- Publishing a Python project on GitHub
